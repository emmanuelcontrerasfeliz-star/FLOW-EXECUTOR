package com.flowexecutor.app

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import org.luaj.vm2.Globals
import org.luaj.vm2.lib.jse.JsePlatform
import java.io.BufferedReader
import java.io.InputStreamReader

class MainActivity : Activity() {
    private lateinit var editor: EditText
    private lateinit var console: TextView
    private lateinit var globals: Globals
    private val red = Color.rgb(255, 30, 55)
    private val dark = Color.rgb(12, 12, 14)
    private val panel = Color.rgb(25, 24, 27)
    private val openCode = 101
    private val saveCode = 102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        globals = JsePlatform.standardGlobals()
        buildUi()
        log("[INFO] FLOW EXECUTOR listo.")
        log("[INFO] Editor local listo. No se conecta ni inyecta en Roblox.")
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(18), dp(16), dp(16))
            setBackgroundColor(dark)
        }
        val title = TextView(this).apply {
            text = "♛  FLOW EXECUTOR"
            textSize = 27f
            setTextColor(red)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(4))
        }
        val subtitle = TextView(this).apply {
            text = "EDITOR DE SCRIPTS • INTERFAZ LOCAL"
            textSize = 11f
            letterSpacing = .18f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(18))
        }
        root.addView(title)
        root.addView(subtitle)

        val topActions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(8))
        }
        topActions.addView(makeButton("Pegar", red) {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = clipboard.primaryClip
            if (clip != null && clip.itemCount > 0) {
                editor.setText(clip.getItemAt(0).coerceToText(this@MainActivity))
                log("[INFO] Texto pegado desde el portapapeles.")
            } else log("[WARN] El portapapeles está vacío.")
        }, LinearLayout.LayoutParams(0, dp(44), 1f))
        topActions.addView(makeButton("Minimizar", Color.DKGRAY) {
            if (Settings.canDrawOverlays(this)) {
                startService(Intent(this, BubbleService::class.java))
                moveTaskToBack(true)
            } else {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                Toast.makeText(this, "Activa 'Mostrar sobre otras apps' y vuelve a FLOW EXECUTOR.", Toast.LENGTH_LONG).show()
            }
        }, LinearLayout.LayoutParams(0, dp(44), 1f))
        root.addView(topActions)

        editor = EditText(this).apply {
            hint = "Escribe o pega tu código Lua aquí..."
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            textSize = 14f
            gravity = Gravity.TOP or Gravity.START
            typeface = Typeface.MONOSPACE
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(panel)
            minLines = 11
            isSingleLine = false
        }
        root.addView(editor, LinearLayout.LayoutParams(-1, 0, 1f))

        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(6)) }
        row1.addView(makeButton("Abrir", Color.DKGRAY) { openFile() }, weighted())
        row1.addView(makeButton("Guardar", Color.DKGRAY) { saveFile() }, weighted())
        row1.addView(makeButton("Copiar", Color.DKGRAY) { copyCode() }, weighted())
        root.addView(row1)

        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        row2.addView(makeButton("▶ Probar Lua local", red) { runLua() }, LinearLayout.LayoutParams(0, dp(50), 2f))
        row2.addView(makeButton("Limpiar", Color.DKGRAY) { editor.text.clear(); log("[INFO] Editor limpiado.") }, LinearLayout.LayoutParams(0, dp(50), 1f))
        root.addView(row2)

        val consoleTitle = TextView(this).apply {
            text = "CONSOLA"
            setTextColor(red)
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(16), 0, dp(6))
        }
        root.addView(consoleTitle)
        console = TextView(this).apply {
            text = "Consola preparada.\n"
            setTextColor(Color.LTGRAY)
            textSize = 12f
            typeface = Typeface.MONOSPACE
            setPadding(dp(10), dp(10), dp(10), dp(10))
            setBackgroundColor(panel)
            minHeight = dp(105)
        }
        val scroll = ScrollView(this).apply { addView(console) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, dp(120)))

        val footer = TextView(this).apply {
            text = "Interfaz independiente • No se conecta a Roblox"
            setTextColor(Color.GRAY)
            textSize = 10f
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, 0)
        }
        root.addView(footer)
        setContentView(root)
    }

    private fun weighted() = LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginEnd = dp(5) }

    private fun makeButton(label: String, color: Int, action: () -> Unit): Button {
        return Button(this).apply {
            text = label
            textSize = 12f
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundColor(color)
            setOnClickListener { action() }
        }
    }

    private fun runLua() {
        val code = editor.text.toString()
        if (code.isBlank()) { log("[WARN] Escribe código Lua primero."); return }
        try {
            val result = globals.load(code, "FLOW_EDITOR").call()
            log("[OK] Código ejecutado.")
            if (!result.isnil()) log(result.tojstring())
        } catch (e: Exception) {
            log("[ERROR] ${e.message ?: "Error de Lua"}")
        }
    }

    private fun log(message: String) {
        console.append(message + "\n")
    }

    private fun copyCode() {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Lua script", editor.text))
        log("[INFO] Código copiado.")
    }

    private fun openFile() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/*"
        }
        startActivityForResult(intent, openCode)
    }

    private fun saveFile() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/plain"
            putExtra(Intent.EXTRA_TITLE, "script.lua")
        }
        startActivityForResult(intent, saveCode)
    }

    @Deprecated("Use Activity Result APIs in production")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK) return
        val uri: Uri = data?.data ?: return
        try {
            if (requestCode == openCode) {
                contentResolver.openInputStream(uri)?.use { input ->
                    editor.setText(BufferedReader(InputStreamReader(input)).readText())
                }
                log("[INFO] Archivo abierto.")
            } else if (requestCode == saveCode) {
                contentResolver.openOutputStream(uri)?.use { it.write(editor.text.toString().toByteArray()) }
                log("[INFO] Archivo guardado.")
            }
        } catch (e: Exception) { log("[ERROR] ${e.message}") }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
