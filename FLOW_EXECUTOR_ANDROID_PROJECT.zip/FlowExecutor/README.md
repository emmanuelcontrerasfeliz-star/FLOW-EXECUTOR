# FLOW EXECUTOR — Android

Proyecto Android de editor Lua local. **No inyecta código en Roblox ni interactúa con procesos de otros juegos.**

## Crear un APK instalable

Este entorno de entrega no incluye Android SDK ni Gradle, por lo que no es posible compilar aquí el archivo APK. El proyecto incluye un flujo automático para construirlo en GitHub Actions:

1. Descarga y descomprime este ZIP.
2. Sube la carpeta `FlowExecutor` a un repositorio nuevo de GitHub.
3. Abre la pestaña **Actions** del repositorio.
4. Ejecuta **Construir APK** con **Run workflow** (o espera a que termine la compilación).
5. Cuando finalice, abre la ejecución y descarga el artefacto **FLOW-EXECUTOR-APK**.
6. Dentro del ZIP descargado estará `app-debug.apk`. Pásalo al Android e instálalo. Si Android lo solicita, permite instalar aplicaciones desde la fuente que usaste para abrir el APK.

El APK de depuración es instalable, pero no está publicado en Play Store.

## Requisitos de compilación
- JDK 17
- Android SDK Platform 35
- Android Build Tools 35.0.0
- Gradle compatible con Android Gradle Plugin 8.7.3

## Funciones
- Editor de código Lua
- Prueba de código Lua local con LuaJ
- Botón Pegar desde el portapapeles
- Botón Minimizar para enviar la app al segundo plano
- Consola
- Abrir, guardar y copiar scripts

El botón Minimizar envía la aplicación al segundo plano (no crea una ventana flotante sobre Roblox). La ejecución Lua es independiente y no proporciona APIs de Roblox (`game`, `workspace`, `Players`, etc.).


## Burbuja flotante
Al tocar **Minimizar**, Android puede pedir permiso para "Mostrar sobre otras apps". Actívalo para FLOW EXECUTOR. La burbuja roja con la letra F se puede arrastrar y tocar para volver a abrir la aplicación. La burbuja solo abre el editor; no se conecta a Roblox ni ejecuta scripts dentro del juego.
